﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTPZaikovAPP.Model
{
    public class Member
    {
        public DTP DTPId { get; set; }
        public Driver DriverId { get; set; }
        public Car CarId { get; set; } 
    }
}
